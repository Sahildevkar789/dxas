const mongoose = require("mongoose");

const initData= require("../init/data");
const Listing = require("../models/listing.js");

// const MONGOURL = mongoose.connect('mongodb://127.0.0.1:27017/test');
const MONGOURL = 'mongodb://127.0.0.1:27017/wonder';
// main().then (() => {
//     console.log("connected to DB");
// }).catch((err) => {console.log(err)});

// async function main() {
//     await mongoose.connect(MONGOURL);
// }

// const initDB = async () => {
//     await Listing.deleteMany({});
//     initData.data = initData.data.map((obj)=>({...
//     });
//     await Listing.insertMany(formattedData);
//     console.log("DB initialized");};
// // };
// initDB();
// const initDB = async () => {
//     await Listing.deleteMany({});
//     initData.data = initData.data.map((obj)=>({...obj , owner :"6783592f5034a792daee2c0b"}));
//     const formattedData = initData.data.map(item => {
//         if (item.image) {
//             item.image = item.image.url;
//         }
//         return item;
//     });
//     await Listing.insertMany(formattedData);
//     console.log("DB initialized");
// };



main()
  .then(() => {
    console.log("connected to DB");
  })
  .catch((err) => {
    console.log(err);
  });

async function main() {
  await mongoose.connect(MONGOURL);
}

const initDB = async () => {
  await Listing.deleteMany({});
  initData.data = initData.data.map((obj)=>({...obj , owner :"6783592f5034a792daee2c0b"}));
  await Listing.insertMany(initData.data);
  console.log("data was initialized");
};

initDB();
